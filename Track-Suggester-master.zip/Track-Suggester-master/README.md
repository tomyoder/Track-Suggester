# _{Track Suggester}_

#### _{An app to help aspiring programmers.}, {2/17/17}_

#### By _**{Tom Yoder}**_

## Description

_{An app to help aspiring programmers find their way through choices of classes, languages, etc. using a survey to gather user input. Utilizes branching and other features and structures to satisfy assignment requirements}_


## Known Bugs

_{All known bugs removed as possible within assignment time limits. }_

## Support and contact details

_{Contact Tom Yoder, motredoy@gmail.com, with any comments or questions}_

## Technologies Used

_{HTML, CSS, Bootstrap, Javascript, Jquery}_

### License

*{MIT}*

Copyright (c) 2016 **_{Tom Yoder}_**
